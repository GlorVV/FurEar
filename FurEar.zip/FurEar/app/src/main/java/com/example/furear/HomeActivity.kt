package com.example.furear

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.widget.ViewPager2
import com.example.furear.ui.theme.FurEarTheme
import com.example.furear.ui.theme.ViewPagerAdapter

class HomeActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FurEarTheme {
                SwipeableScreen()
            }
        }
    }
}

@Composable
fun SwipeableScreen(modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier.fillMaxSize(),
        factory = { context ->
            val view = android.view.View.inflate(context, R.layout.activity_home, null)
            val viewPager = view.findViewById<ViewPager2>(R.id.view_pager)
            val fragmentActivity = context as FragmentActivity
            viewPager.adapter = ViewPagerAdapter(fragmentActivity)
            view
        },
        update = {
        }
    )
}


