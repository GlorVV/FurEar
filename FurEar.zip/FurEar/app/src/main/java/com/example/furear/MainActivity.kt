package com.example.furear

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.SearchView
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.net.URLEncoder

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_welcome)
        val rootView = findViewById<android.view.View>(android.R.id.content)

//        val searchView = findViewById<SearchView>(R.id.searchView)

//        fun searchYouTube(query: String) {
//            val url = "https://www.googleapis.com/youtube/v3/search" + "?part=snippet&type=video&q=${URLEncoder.encode(query, "UTF-8")}&key=AIzaSyCvY41Bh5VdE_0WHspIZtbLOuRwj_MrAuY"
//        }
//
//        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
//            override fun onQueryTextSubmit(query: String?): Boolean {
//                if (!query.isNullOrEmpty()) {
//                    searchYouTube(query)
//                }
//                return true
//            }
//
//            override fun onQueryTextChange(newText: String?): Boolean {
//                return false
//            }
//        })



        lifecycleScope.launch {
            delay(1200)
            rootView.animate()
                .alpha(0f)
                .setDuration(400)
                .withEndAction {
                    setContentView(R.layout.activity_auth)
                    rootView.alpha = 0f
                    rootView.animate()
                        .alpha(1f)
                        .setDuration(400)
                        .start()

                    val loginButton = findViewById<Button>(R.id.login_button)
                    loginButton.setOnClickListener {
                        val intent = Intent(this@MainActivity, HomeActivity::class.java)
                        startActivity(intent)
                        finish()
                    }
                }.start()
        }
    }
}
